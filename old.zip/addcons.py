# add_constellations.py
import csv

# Constellation data for each star
constellation_map = {
    "Sun": "Solar System",
    "SiriusA": "Canis Major",
    "Canopus": "Carina",
    "Arcturus": "Boötes",
    "AlphaCentauriA": "Centaurus",
    "Vega": "Lyra",
    "Capella": "Auriga",
    "Rigel": "Orion",
    "ProcyonA": "Canis Minor",
    "Betelgeuse": "Orion",
    "Achemar": "Eridanus",
    "Hadar": "Centaurus",
    "Altair": "Aquila",
    "Aldebaran": "Taurus",
    "Spica": "Virgo",
    "Antares": "Scorpius",
    "Fomalhaut": "Piscis Austrinus",
    "Pollux": "Gemini",
    "Deneb": "Cygnus",
    "BetaCrucis": "Crux",
    "Regulus": "Leo",
    "Acrux": "Crux",
    "Adhara": "Canis Major",
    "Shaula": "Scorpius",
    "Bellatrix": "Orion",
    "Castor": "Gemini",
    "Gacrux": "Crux",
    "BetaCentauri": "Centaurus",
    "AlphaCentauriB": "Centaurus",
    "AlNa'ir": "Grus",
    "Miaplacidus": "Carina",
    "Elnath": "Taurus",
    "Alnilam": "Orion",
    "Mirfak": "Perseus",
    "Alnitak": "Orion",
    "Dubhe": "Ursa Major",
    "Alioth": "Ursa Major",
    "Peacock": "Pavo",
    "KausAustralis": "Sagittarius",
    "ThetaScorpii": "Scorpius",
    "Atria": "Triangulum Australe",
    "Alkaid": "Ursa Major",
    "AlphaCrucisB": "Crux",
    "Avior": "Carina",
    "DeltaCanisMajoris": "Canis Major",
    "Alhena": "Gemini",
    "Menkalinan": "Auriga",
    "Polaris": "Ursa Minor",
    "Mirzam": "Canis Major",
    "DeltaVulpeculae": "Vulpecula",
    "ProximaCentauri": "Centaurus",
    "Barnard'sStar": "Ophiuchus",
    "Barnard": "Ophiuchus",
    "BarnardsStar": "Ophiuchus",
    "BarnardStar": "Ophiuchus",
    "Barnards": "Ophiuchus",
    "Wolf359": "Leo",
    "HD93735": "Carina",
    "L726-8": "Cetus",
    "UVCeti": "Cetus",
    "SiriusB": "Canis Major",
    "Ross154": "Sagittarius",
    "Ross248": "Andromeda",
    "EpsilonEridani": "Eridanus",
    "Ross128": "Virgo",
    "L789-6": "Aquarius",
    "GXAndromedae": "Andromeda",
    "GQAndromedae": "Andromeda",
    "EpsilonIndi": "Indus",
    "61CygniA": "Cygnus",
    "61CygniB": "Cygnus",
    "Struve2398A": "Draco",
    "Struve2398B": "Draco",
    "TauCeti": "Cetus",
    "ProcyonB": "Canis Minor",
    "Lacaille9352": "Piscis Austrinus",
    "G51-I5": "Unknown",
    "YZCeti": "Cetus",
    "BD+051668": "Canis Minor",
    "Lacaille8760": "Microscopium",
    "KapteynsStar": "Pictor",
    "Kruger60A": "Cepheus",
    "Kruger60B": "Cepheus",
    "BD-124523": "Virgo",
    "Ross614A": "Monoceros",
    "Wolf424A": "Virgo",
    "vanMaanen'sStar": "Pisces",
    "TZArietis": "Aries",
    "HD225213": "Sculptor",
    "ADLeonis": "Leo",
    "40EridaniA": "Eridanus",
    "40EridaniB": "Eridanus",
    "40EridaniC": "Eridanus",
    "70OphiuchiA": "Ophiuchus",
    "70OphiuchiB": "Ophiuchus",
    "EVLacertae": "Lacerta"
}

# Read stars_merged.csv (which has RA and Dec)
stars = []
with open("stars_merged.csv", newline="", encoding="utf-8") as f:
    reader = csv.DictReader(f)
    fieldnames = reader.fieldnames
    for row in reader:
        stars.append(row)

# Add constellation column
with open("stars_with_constellations.csv", "w", newline="", encoding="utf-8") as f:
    # Add 'constellation' to fieldnames
    new_fieldnames = list(fieldnames) + ["constellation"]
    writer = csv.DictWriter(f, fieldnames=new_fieldnames)
    writer.writeheader()
    
    for star_data in stars:
        star_name = star_data["star"].strip()
        # Get constellation from map, default to "Unknown" if not found
        constellation = constellation_map.get(star_name, "Unknown")
        star_data["constellation"] = constellation
        writer.writerow(star_data)

print("Constellations added to stars_merged.csv! Created stars_with_constellations.csv")
print(f"Added constellation data for {len(stars)} stars")
print("\nThis file has magnitude, temp, type, distance, radius, Ra, Dec, AND constellation")
print("\nIf it looks good:")
print("1. You can rename stars_with_constellations.csv to stars.csv")
print("2. Or keep stars_merged.csv as backup and work with the new file")